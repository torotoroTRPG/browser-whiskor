# browser-whiskor Test Report

**Mode:** full  
**Started:** 2026-05-22 14:43:00  
**Duration:** 3.2s  

## Summary

| Metric       | Value |
|-------------:|-------|
| Total tests  | 299 |
| Passed       | 299 |
| Failed       | 0 |
| Pass rate    | 100.0% |

## Suites
### unit tests (mocked)

_Duration: 2.1s_

| Suite | Tests | Passed | Failed | Rate |
|-------|------:|-------:|------:|-----:|
| 3.1 Beacon Tracking | 19 | 19 | 0 | 100.0%
| 6.1 Bridge | 2 | 2 | 0 | 100.0%
| Cache Integrity | 9 | 9 | 0 | 100.0%
| 2.4 Animation | 16 | 16 | 0 | 100.0%
| 2.5 Undo/Redo | 22 | 22 | 0 | 100.0%
| 2.3 Canvas Interaction (INTERACT mode) | 20 | 20 | 0 | 100.0%
| 2.2 Canvas Rendering | 27 | 27 | 0 | 100.0%
| 2.1 Viewport Consistency | 14 | 14 | 0 | 100.0%
| 8.2 Config Change Log | 2 | 2 | 0 | 100.0%
| 8.1 Config Loader | 3 | 3 | 0 | 100.0%
| 11.1 Delta Engine | 21 | 21 | 0 | 100.0%
| 11.2 Pattern Registry | 7 | 7 | 0 | 100.0%
| 5.2 Action Handlers | 31 | 31 | 0 | 100.0%
| 5.1 Element Resolution | 19 | 19 | 0 | 100.0%
| 4.4 Control Tools | 7 | 7 | 0 | 100.0%
| 4.2 Read Tools | 10 | 10 | 0 | 100.0%
| 4.1 Write Tools | 15 | 15 | 0 | 100.0%
| Seen Text Tracker | 16 | 16 | 0 | 100.0%
| 1.2 HTTP API | 25 | 25 | 0 | 100.0%
| 1.3 Message Routing | 14 | 14 | 0 | 100.0%
| 1.1 WebSocket Connection Management | 14 | 14 | 0 | 100.0%
| 7.2 State Navigator | 18 | 18 | 0 | 100.0%
| 7.1 State Store | 3 | 3 | 0 | 100.0%
| 11.3 Tool Manager | 21 | 21 | 0 | 100.0%
### integration & stress tests (real WS)

_Duration: 1.3s_

| Suite | Tests | Passed | Failed | Rate |
|-------|------:|-------:|------:|-----:|
| 3.2 Delta Message Flow | 4 | 4 | 0 | 100.0%
| 10.2 Error Recovery | 5 | 5 | 0 | 100.0%
| 10.1 Full Flow | 4 | 4 | 0 | 100.0%
| 10.3 Multi-Tab & Session Recovery | 7 | 7 | 0 | 100.0%
| 9.1 Large Data | 6 | 6 | 0 | 100.0%
| 9.2 Long Session | 5 | 5 | 0 | 100.0%

---

*Report generated at 2026-05-22 14:43:00 by tests\run.ps1*
