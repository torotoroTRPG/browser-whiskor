/**
 * background/background.js  –  MV2 Persistent Background Page
 *
 * MV3 Service Worker と違い永続的に生存するため:
 *   - WebSocket は切断されない → 再接続キュー不要
 *   - browser.webRequest で全トラフィックをブラウザレベルで傍受可能
 *   - filterResponseData でレスポンスボディをストリーム取得可能
 *   - Authorization ヘッダー等も完全に見える
 */
'use strict';

const _b = (typeof browser !== 'undefined') ? browser : chrome;

const WS_URL      = 'ws://0.0.0.0:7891';
const RECONNECT_MS = 3000;

let ws      = null;
let wsReady = false;

const panelPorts = new Map(); // tabId → port

// ── WebSocket（永続ページなので接続は維持され続ける）────────────────────────

function connectWs() {
  try { ws = new WebSocket(WS_URL); }
  catch (_) { setTimeout(connectWs, RECONNECT_MS); return; }

  ws.addEventListener('open', () => {
    wsReady = true;
    broadcastToPanels({ type: 'SERVER_STATUS', connected: true });
    console.log('[SI] Server connected');
  });

  ws.addEventListener('close', () => {
    wsReady = false;
    ws = null;
    broadcastToPanels({ type: 'SERVER_STATUS', connected: false });
    setTimeout(connectWs, RECONNECT_MS);
  });

  ws.addEventListener('error', () => { wsReady = false; });

  ws.addEventListener('message', (event) => {
    try {
      const msg = JSON.parse(event.data);

      if (msg.type === 'SET_CONFIG') {
        _b.storage.local.set({ SI_CONFIG: msg.config });
        // 全タブに CONFIG_UPDATE を inject
        _b.tabs.query({}, (tabs) => {
          for (const tab of tabs) {
            _b.tabs.executeScript(tab.id, {
              code: `window.postMessage({__SITE_INSPECTOR__:true,type:'CONFIG_UPDATE',payload:${JSON.stringify(msg.config)}}, '*')`,
              runAt: 'document_idle',
            }).catch(() => {});
          }
        });
        broadcastToPanels({ type: 'CONFIG_UPDATED', config: msg.config });
        return;
      }

      if (msg.type === 'MANUAL_COLLECT') {
        _b.tabs.executeScript(msg.tabId, {
          code: `window.postMessage({__SITE_INSPECTOR__:true,type:'MANUAL_COLLECT',payload:${JSON.stringify({ plugins: msg.plugins || null })}}, '*')`,
          runAt: 'document_idle',
        }).catch(() => {});
      }
    } catch (_) {}
  });
}

function sendToServer(data) {
  if (wsReady && ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(data));
  }
  // MV2 永続ページなので queue は不要。未接続時は捨てる（サーバー再接続後に再収集）
}

connectWs();

// ── ページからのメッセージ（bridge.js 経由）───────────────────────────────

_b.runtime.onMessage.addListener((message, sender) => {
  if (message.from !== 'collector') return;

  const enriched = {
    ...message,
    tabId:   sender.tab && sender.tab.id,
    frameId: sender.frameId,
  };

  sendToServer(enriched);
  const p = panelPorts.get(sender.tab && sender.tab.id);
  if (p) { try { p.postMessage(enriched); } catch (_) {} }
});

// ── DevTools パネル接続 ───────────────────────────────────────────────────

_b.runtime.onConnect.addListener((port) => {
  if (!port.name.startsWith('devtools-')) return;

  const tabId = parseInt(port.name.replace('devtools-', ''), 10);
  panelPorts.set(tabId, port);
  port.postMessage({ type: 'SERVER_STATUS', connected: wsReady });

  port.onMessage.addListener((msg) => {
    if (msg.type === 'MANUAL_COLLECT') {
      _b.tabs.executeScript(tabId, {
        code: `window.postMessage({__SITE_INSPECTOR__:true,type:'MANUAL_COLLECT',payload:${JSON.stringify({ plugins: msg.plugins || null })}}, '*')`,
        runAt: 'document_idle',
      }).catch(() => {});
    }
    if (msg.type === 'SET_CONFIG') {
      _b.storage.local.set({ SI_CONFIG: msg.config });
      sendToServer({ type: 'CONFIG_FROM_PANEL', config: msg.config });
    }
  });

  port.onDisconnect.addListener(() => { panelPorts.delete(tabId); });
});

function broadcastToPanels(msg) {
  for (const port of panelPorts.values()) {
    try { port.postMessage(msg); } catch (_) {}
  }
}

// ════════════════════════════════════════════════════════════════════════════
// ── webRequest ネットワーク傍受（ブラウザレベル）──────────────────────────
//
//  MV3 の fetch/XHR パッチでは取れなかったもの:
//   - Service Worker 発のリクエスト
//   - <link rel=prefetch> / preload
//   - ブラウザ内部リクエスト (favicon等を除く)
//   - Authorization / Cookie ヘッダー（MAIN world からは見えない）
//   - レスポンスボディ全体（filterResponseData でストリーム取得）
// ════════════════════════════════════════════════════════════════════════════

// リクエスト情報を一時保管 (requestId → entry)
const pendingReqs = new Map();

// レスポンスボディを蓄積するバッファ (requestId → Uint8Array[])
const bodyBuffers = new Map();

const SKIP_TYPES = new Set(['image', 'media', 'font', 'stylesheet', 'ping', 'other']);
const BODY_MAX   = 4096; // バイト（ページJS版の 500 より大幅に多く取れる）

const TOKEN_PATTERNS = [
  { name: 'Bearer',  re: /^bearer\s+(.+)/i },
  { name: 'Basic',   re: /^basic\s+(.+)/i  },
  { name: 'JWT',     re: /^(ey[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)/ },
  { name: 'API-Key', re: /^(sk-[A-Za-z0-9]{32,}|[A-Za-z0-9]{32,})$/ },
];
const TOKEN_HEADERS = new Set([
  'authorization', 'x-auth-token', 'x-api-key', 'x-access-token',
  'x-amz-security-token', 'x-goog-api-key',
]);

function detectToken(name, value) {
  if (!TOKEN_HEADERS.has(name.toLowerCase())) return null;
  for (const p of TOKEN_PATTERNS) {
    if (p.re.test(value)) return { type: p.name, header: name, preview: value.slice(0, 24) + '…' };
  }
  return { type: 'Unknown', header: name, preview: value.slice(0, 24) + '…' };
}

// 1. リクエスト開始 + ボディ取得
_b.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (SKIP_TYPES.has(details.type)) return {};
    if (details.tabId < 0) return {}; // バックグラウンドリクエストは除外

    const entry = {
      reqId:          details.requestId,
      url:            details.url,
      method:         details.method,
      tabId:          details.tabId,
      resourceType:   details.type,
      ts:             details.timeStamp,
      requestHeaders: {},
      tokens:         [],
      requestBody:    null,
      status:         null,
      responseHeaders:{},
      source:         'webrequest',  // page-js と区別するタグ
    };

    // リクエストボディ
    if (details.requestBody) {
      try {
        if (details.requestBody.raw) {
          const bytes = details.requestBody.raw.reduce((acc, c) => {
            return acc + new TextDecoder().decode(c.bytes);
          }, '');
          entry.requestBody = bytes.slice(0, BODY_MAX);
        } else if (details.requestBody.formData) {
          entry.requestBody = JSON.stringify(details.requestBody.formData).slice(0, BODY_MAX);
        }
      } catch (_) {}
    }

    pendingReqs.set(details.requestId, entry);
    bodyBuffers.set(details.requestId, []);

    // filterResponseData でレスポンスボディをストリーム取得
    try {
      const filter  = _b.webRequest.filterResponseData(details.requestId);
      const decoder = new TextDecoder('utf-8');
      let   total   = 0;

      filter.ondata = (event) => {
        // パススルー（ページに影響しない）
        filter.write(event.data);

        if (total < BODY_MAX) {
          const chunk = decoder.decode(event.data, { stream: true });
          const buf   = bodyBuffers.get(details.requestId);
          if (buf != null) {
            buf.push(chunk);
            total += chunk.length;
          }
        }
      };

      filter.onstop = () => {
        filter.disconnect();

        const entry = pendingReqs.get(details.requestId);
        const buf   = bodyBuffers.get(details.requestId);
        bodyBuffers.delete(details.requestId);

        if (!entry || !buf) return;

        const raw = buf.join('').slice(0, BODY_MAX);
        // テキスト系のみ保存（バイナリは除外）
        if (raw && /[\x00-\x08\x0E-\x1F]/.test(raw.slice(0, 64)) === false) {
          entry.responseBody = raw;
        }

        // エントリが完成したので送信
        sendToServer({
          from:    'collector',
          type:    'NETWORK_REQUEST',
          tabId:   entry.tabId,
          payload: entry,
          ts:      Date.now(),
        });

        broadcastToPanels({
          type:    'NETWORK_REQUEST',
          tabId:   entry.tabId,
          payload: entry,
        });

        pendingReqs.delete(details.requestId);
      };

      filter.onerror = () => {
        // フィルターエラー時でも基本情報は送る
        const entry = pendingReqs.get(details.requestId);
        bodyBuffers.delete(details.requestId);
        if (entry) {
          sendToServer({ from: 'collector', type: 'NETWORK_REQUEST', tabId: entry.tabId, payload: entry, ts: Date.now() });
          pendingReqs.delete(details.requestId);
        }
      };
    } catch (_) {
      // filterResponseData が使えない場合 (一部コンテキスト) はヘッダーだけ送る
    }

    return {}; // blocking だが変更なし（傍受のみ）
  },
  { urls: ['<all_urls>'], types: ['main_frame','sub_frame','xmlhttprequest','fetch','websocket','script','other'] },
  ['requestBody', 'blocking']
);

// 2. リクエストヘッダー取得（Authorization など）
_b.webRequest.onSendHeaders.addListener(
  (details) => {
    const entry = pendingReqs.get(details.requestId);
    if (!entry) return;

    for (const h of (details.requestHeaders || [])) {
      entry.requestHeaders[h.name] = h.value;
      const tok = detectToken(h.name, h.value || '');
      if (tok) entry.tokens.push(tok);
    }
  },
  { urls: ['<all_urls>'] },
  ['requestHeaders']
);

// 3. レスポンスヘッダー取得
_b.webRequest.onHeadersReceived.addListener(
  (details) => {
    const entry = pendingReqs.get(details.requestId);
    if (!entry) return;
    entry.status = details.statusCode;
    for (const h of (details.responseHeaders || [])) {
      entry.responseHeaders[h.name] = h.value;
    }
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

// 4. エラー処理（接続失敗・タイムアウト）
_b.webRequest.onErrorOccurred.addListener(
  (details) => {
    const entry = pendingReqs.get(details.requestId);
    if (!entry) return;
    entry.error = details.error;
    sendToServer({ from: 'collector', type: 'NETWORK_ERROR', tabId: entry.tabId, payload: entry, ts: Date.now() });
    pendingReqs.delete(details.requestId);
    bodyBuffers.delete(details.requestId);
  },
  { urls: ['<all_urls>'] }
);

console.log('[SI] MV2 background ready — webRequest + filterResponseData active');
