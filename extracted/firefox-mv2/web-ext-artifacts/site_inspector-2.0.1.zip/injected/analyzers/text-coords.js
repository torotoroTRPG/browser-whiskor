/**
 * analyzers/text-coords.js  –  MAIN world
 * Extracts all visible text with absolute page coordinates.
 * Output is Tesseract.js-compatible (level/page_num/block_num/etc.)
 * plus browser-specific extensions (xpath, fontSize, color, ...).
 */
'use strict';

(function () {
  const registry = window.__SI_REGISTRY__;
  if (!registry) return;

  // ── Constants ─────────────────────────────────────────────────────────────
  const SKIP_TAGS = new Set(['SCRIPT','STYLE','NOSCRIPT','TEMPLATE','SVG','MATH','CANVAS','AUDIO','VIDEO']);
  const BLOCK_TAGS = new Set([
    'DIV','P','H1','H2','H3','H4','H5','H6',
    'SECTION','ARTICLE','ASIDE','MAIN','HEADER','FOOTER',
    'LI','TD','TH','BLOCKQUOTE','PRE','FIGURE','FORM','TABLE',
    'ADDRESS','DETAILS','SUMMARY','CAPTION','COL','COLGROUP',
    'DT','DD','DL','TR',
  ]);
  const LINE_THRESHOLD = 4; // px Y-diff to consider a new line

  // ── Helpers ───────────────────────────────────────────────────────────────
  function isBlockLevel(el) {
    if (!el) return false;
    if (BLOCK_TAGS.has(el.tagName)) return true;
    try {
      const d = getComputedStyle(el).display;
      return d === 'block' || d === 'flex' || d === 'grid' || d === 'table';
    } catch { return false; }
  }

  function findBlockAncestor(el) {
    let node = el;
    while (node && node !== document.body) {
      if (isBlockLevel(node)) return node;
      node = node.parentElement;
    }
    return document.body;
  }

  function getSimpleXPath(el) {
    const parts = [];
    let node = el;
    while (node && node !== document.documentElement) {
      if (node.id) { parts.unshift(`//*[@id="${node.id}"]`); break; }
      const tag = node.tagName.toLowerCase();
      const sibs = [...(node.parentElement?.children || [])].filter(c => c.tagName === node.tagName);
      const idx  = sibs.indexOf(node) + 1;
      parts.unshift(sibs.length > 1 ? `${tag}[${idx}]` : tag);
      node = node.parentElement;
    }
    if (!parts.length) return '/html/body';
    if (parts[0].startsWith('//*')) return parts[0];
    return '/html/body/' + parts.join('/');
  }

  // ── Core extraction ───────────────────────────────────────────────────────
  function extractTextWithCoords(options = {}) {
    const {
      includeHidden    = false,
      includeOffscreen = false,
      maxWords         = 5000,
    } = options;

    const scrollX = window.scrollX, scrollY = window.scrollY;
    const vw = window.innerWidth,   vh = window.innerHeight;

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const p = node.parentElement;
          if (!p) return NodeFilter.FILTER_REJECT;
          if (SKIP_TAGS.has(p.tagName)) return NodeFilter.FILTER_REJECT;
          if (!node.textContent.trim()) return NodeFilter.FILTER_SKIP;
          if (!includeHidden) {
            try {
              const cs = getComputedStyle(p);
              if (cs.display === 'none' || cs.visibility === 'hidden' ||
                  parseFloat(cs.opacity) === 0) return NodeFilter.FILTER_REJECT;
            } catch (_) {}
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      }
    );

    const words = [];
    let blockNum = 0, parNum = 0, lineNum = 0, wordNum = 0;
    let lastBlockEl = null, lastParEl = null, lastLineY = -Infinity;

    while (walker.nextNode() && words.length < maxWords) {
      const textNode = walker.currentNode;
      const parent   = textNode.parentElement;

      // Block / paragraph counters
      const blockEl = findBlockAncestor(parent);
      if (blockEl !== lastBlockEl) {
        blockNum++;
        parNum = 0;
        lastBlockEl = blockEl;
      }
      if (isBlockLevel(parent) && parent !== lastParEl) {
        parNum++;
        lastParEl = parent;
      }

      // Split into words by whitespace
      const wordRe = /\S+/g;
      let match;
      while ((match = wordRe.exec(textNode.textContent)) !== null) {
        let rect;
        try {
          const range = document.createRange();
          range.setStart(textNode, match.index);
          range.setEnd(textNode, match.index + match[0].length);
          rect = range.getBoundingClientRect();
        } catch (_) { continue; }

        if (rect.width === 0 && rect.height === 0) continue;

        const inViewport = (rect.top >= 0 && rect.bottom <= vh &&
                            rect.left >= 0 && rect.right <= vw);
        if (!includeOffscreen && !inViewport) continue;

        // Line detection by Y position
        if (Math.abs(rect.top - lastLineY) > LINE_THRESHOLD) {
          lineNum++;
          lastLineY = rect.top;
        }

        const absX = Math.round(rect.left + scrollX);
        const absY = Math.round(rect.top  + scrollY);

        let cs;
        try { cs = getComputedStyle(parent); } catch (_) { cs = {}; }

        words.push({
          // ── Tesseract互換フィールド ──────────────────────────────
          level:     5,
          page_num:  1,
          block_num: blockNum,
          par_num:   parNum,
          line_num:  lineNum,
          word_num:  ++wordNum,
          left:      absX,
          top:       absY,
          width:     Math.round(rect.width),
          height:    Math.round(rect.height),
          conf:      100,
          text:      match[0],
          // ── 拡張フィールド ───────────────────────────────────────
          element:          parent.tagName.toLowerCase(),
          elementId:        parent.id || null,
          elementClasses:   [...parent.classList].slice(0, 5).join(' ') || null,
          xpath:            getSimpleXPath(parent),
          fontSize:         parseFloat(cs.fontSize) || null,
          fontFamily:       (cs.fontFamily || '').split(',')[0].replace(/['"]/g, '').trim() || null,
          fontWeight:       cs.fontWeight || null,
          fontStyle:        cs.fontStyle || null,
          color:            cs.color || null,
          backgroundColor:  cs.backgroundColor || null,
          isLink:           !!parent.closest('a'),
          inViewport,
          isHidden:         false,
          viewportX:        Math.round(rect.left),
          viewportY:        Math.round(rect.top),
          absoluteX:        absX,
          absoluteY:        absY,
        });
      }
    }

    return words;
  }

  // ── Aggregations ──────────────────────────────────────────────────────────
  function aggregateLines(words) {
    const map = new Map();
    for (const w of words) {
      const key = `${w.block_num}-${w.line_num}`;
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(w);
    }
    return [...map.values()].map(ws => {
      const left   = Math.min(...ws.map(w => w.left));
      const top    = Math.min(...ws.map(w => w.top));
      const right  = Math.max(...ws.map(w => w.left + w.width));
      const bottom = Math.max(...ws.map(w => w.top  + w.height));
      return {
        level: 4, page_num: 1,
        block_num: ws[0].block_num, par_num: ws[0].par_num, line_num: ws[0].line_num,
        left, top, width: right - left, height: bottom - top,
        conf: 100,
        text:      ws.map(w => w.text).join(' '),
        wordCount: ws.length,
        element:   ws[0].element,
        absoluteX: left, absoluteY: top,
        viewportX: ws[0].viewportX, viewportY: ws[0].viewportY,
      };
    });
  }

  function aggregateBlocks(words) {
    const map = new Map();
    for (const w of words) {
      if (!map.has(w.block_num)) map.set(w.block_num, []);
      map.get(w.block_num).push(w);
    }
    return [...map.values()].map(ws => {
      const left   = Math.min(...ws.map(w => w.left));
      const top    = Math.min(...ws.map(w => w.top));
      const right  = Math.max(...ws.map(w => w.left + w.width));
      const bottom = Math.max(...ws.map(w => w.top  + w.height));
      const el     = document.querySelector(`[id="${ws[0].elementId}"]`) ||
                     findBlockAncestor(document.body);
      return {
        level: 2, page_num: 1, block_num: ws[0].block_num,
        left, top, width: right - left, height: bottom - top,
        conf: 100,
        text: ws.map(w => w.text).join(' ').slice(0, 200),
        element:   ws[0].element,
        elementId: ws[0].elementId,
        role:      el?.getAttribute?.('role') || el?.getAttribute?.('aria-role') || null,
        absoluteX: left, absoluteY: top,
        viewportX: ws[0].viewportX, viewportY: ws[0].viewportY,
      };
    });
  }

  // ── Plugin ────────────────────────────────────────────────────────────────
  registry.register({
    id: 'text-coords',
    name: 'Text Coordinate Extractor',
    version: '1.0.0',
    runAt: 'DOMContentLoaded',
    realtime: false,
    priority: 5,
    emitType: 'TEXT_COORDS',
    cacheTarget: 'visual/text-coords.json',

    _observer: null,
    _reextractTimer: null,

    install(api) {
      const self = this;
      window.addEventListener('load', () => {
        if (!document.body) return;
        self._observer = new MutationObserver(() => {
          clearTimeout(self._reextractTimer);
          self._reextractTimer = setTimeout(() => {
            if (!registry._isEnabled('text-coords')) return;
            const data = self.collect(api);
            if (data) api.emit(self.emitType, data, false);
          }, 1500);
        });
        self._observer.observe(document.body, { childList: true, subtree: true, characterData: true });
      }, { once: true });
    },

    collect(api) {
      const opts  = api.getConfig().options?.textCoords || {};
      const words = extractTextWithCoords(opts);
      const lines = aggregateLines(words);
      const blocks = aggregateBlocks(words);

      return {
        capturedAt:  Date.now(),
        pageUrl:     location.href,
        viewport: {
          width:   window.innerWidth,
          height:  window.innerHeight,
          scrollX: window.scrollX,
          scrollY: window.scrollY,
        },
        totalWords:  words.length,
        totalLines:  lines.length,
        totalBlocks: blocks.length,
        words,
        lines,
        blocks,
        fullText: words.map(w => w.text).join(' '),
      };
    },

    teardown() {
      this._observer?.disconnect();
      clearTimeout(this._reextractTimer);
    },
  });
})();
