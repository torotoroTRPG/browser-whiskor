/**
 * adapters/solid.js  –  MAIN world
 */
'use strict';
(function () {
  const registry = window.__SI_REGISTRY__;
  if (!registry) return;
  registry.register({
    id: 'solid-js', name: 'Solid.js Analyzer', version: '1.0.0',
    runAt: 'load', realtime: false, priority: 10,
    emitType: 'SOLID_SNAPSHOT', cacheTarget: 'solid/',

    detect() {
      return !!(window._$HY || window.solid ||
                document.querySelector('[data-hk]')); // Solid hydration key
    },
    install(api) {},
    collect(api) {
      return {
        capturedAt: Date.now(), framework: 'solid',
        detected: true,
        // Solid.js doesn't expose a public runtime tree API;
        // we can enumerate hydration markers from the DOM
        hydrationKeys: [...document.querySelectorAll('[data-hk]')]
          .map(el => el.getAttribute('data-hk')).slice(0, 100),
        // Expose HY (HydrationData) if available
        hyData: window._$HY
          ? (() => { try { return JSON.parse(JSON.stringify(window._$HY).slice(0, 2000)); } catch { return null; } })()
          : null,
      };
    },
  });
})();
