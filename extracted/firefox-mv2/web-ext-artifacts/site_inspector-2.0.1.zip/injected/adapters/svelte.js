/**
 * adapters/svelte.js  –  MAIN world
 */
'use strict';
(function () {
  const registry = window.__SI_REGISTRY__;
  if (!registry) return;
  registry.register({
    id: 'svelte-meta', name: 'Svelte Analyzer', version: '1.0.0',
    runAt: 'load', realtime: false, priority: 10,
    emitType: 'SVELTE_SNAPSHOT', cacheTarget: 'svelte/',

    detect() {
      return !!(document.querySelector('[data-svelte]') ||
                document.querySelector('[data-svelte-h]') ||
                window.__svelte ||
                document.querySelector('[class*="svelte-"]'));
    },
    install(api) {
      if (!window.__svelte) window.__svelte = { components: [] };
    },
    collect(api) {
      const components = [];
      document.querySelectorAll('[data-svelte-h]').forEach(el => {
        const meta = el.__svelte_meta || el.__s__;
        if (meta) components.push({ source: meta.loc?.file || 'unknown', tag: el.tagName.toLowerCase() });
      });
      const svelteHashes = new Set();
      document.querySelectorAll('[class]').forEach(el => {
        [...el.classList].filter(c => /^svelte-[a-z0-9]{6,}$/.test(c)).forEach(c => svelteHashes.add(c));
      });
      return {
        capturedAt: Date.now(), framework: 'svelte',
        detectionMethod: components.length > 0 ? 'svelte-meta' : 'class-pattern',
        components,
        svelteHashes: [...svelteHashes],
        globalComponents: window.__svelte?.components || [],
      };
    },
  });
})();
