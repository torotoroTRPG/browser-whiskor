/**
 * adapters/angular.js  –  MAIN world
 * Angular 2+ component tree + NgRx detection.
 */
'use strict';

(function () {
  const registry = window.__SI_REGISTRY__;
  if (!registry) return;

  const angularPlugin = {
    id: 'angular-ng',
    name: 'Angular Analyzer',
    version: '1.0.0',
    runAt: 'load',
    realtime: false,
    priority: 10,
    emitType: 'ANGULAR_SNAPSHOT',
    cacheTarget: 'angular/',

    detect() {
      return !!(window.getAllAngularRootElements || window.ng || window.angular);
    },

    install(api) {},

    collect(api) {
      if (!window.ng && !window.getAllAngularRootElements) return null;

      const roots = window.getAllAngularRootElements?.() || [document.querySelector('app-root')].filter(Boolean);
      const trees = [];
      for (const root of roots.slice(0, 3)) {
        const t = this._traverseAngular(root, 0);
        if (t) trees.push(t);
      }

      return {
        capturedAt: Date.now(),
        framework: 'angular',
        version: this._detectVersion(),
        componentTree: trees.length === 1 ? trees[0] : trees,
        services: this._getServices(roots[0]),
        hasNgRx: this._detectNgRx(),
      };
    },

    _traverseAngular(el, depth) {
      if (!el || depth > 40) return null;

      let component = null;
      try { component = window.ng?.getComponent?.(el); } catch (_) {}
      let directives = [];
      try { directives = window.ng?.getDirectives?.(el) || []; } catch (_) {}

      const node = {
        name: component?.constructor?.name || el.tagName?.toLowerCase() || 'unknown',
        depth,
        inputs: null,
        directives: directives.map(d => d?.constructor?.name).filter(Boolean),
        children: [],
        _fw: 'angular',
      };

      if (component) {
        try {
          const entries = Object.entries(component)
            .filter(([k]) => !k.startsWith('_') && !k.startsWith('ng') && typeof component[k] !== 'function')
            .slice(0, 20);
          node.inputs = Object.fromEntries(entries.map(([k, v]) => {
            try { return [k, JSON.parse(JSON.stringify(v).slice(0, 200))]; }
            catch { return [k, '[object]']; }
          }));
        } catch (_) {}
      }

      for (const child of (el.children || [])) {
        const c = this._traverseAngular(child, depth + 1);
        if (c) node.children.push(c);
      }
      return node;
    },

    _detectVersion() {
      try {
        return window.ng?.getVersion?.() ||
               document.querySelector('[ng-version]')?.getAttribute('ng-version') ||
               (window.angular ? '1.x' : null);
      } catch { return null; }
    },

    _getServices(rootEl) {
      try {
        const injector = window.ng?.getInjector?.(rootEl);
        if (!injector) return null;
        return { hasNgRx: this._detectNgRx() };
      } catch { return null; }
    },

    _detectNgRx() {
      // NgRx typically adds window.ngrx or certain Redux DevTools markers
      return !!(window.__REDUX_DEVTOOLS_EXTENSION__ ||
                document.querySelector('[data-ngrx]'));
    },
  };

  registry.register(angularPlugin);
})();
