/**
 * adapters/preact.js  –  MAIN world
 */
'use strict';
(function () {
  const registry = window.__SI_REGISTRY__;
  if (!registry) return;
  registry.register({
    id: 'preact-fiber', name: 'Preact Analyzer', version: '1.0.0',
    runAt: 'load', realtime: false, priority: 10,
    emitType: 'PREACT_SNAPSHOT', cacheTarget: 'preact/',

    detect() {
      // Preact sets __k on DOM nodes (vnode), or window.preact
      return !!(window.preact || document.body?.__k);
    },
    install(api) {},
    collect(api) {
      const root = document.body?.__k || document.getElementById('app')?.__k;
      if (!root) return null;
      return {
        capturedAt: Date.now(),
        framework: 'preact',
        version: window.preact?.version || null,
        componentTree: this._traverse(root, 0),
      };
    },
    _traverse(vnode, depth) {
      if (!vnode || depth > 30) return null;
      const name = typeof vnode.type === 'function'
        ? (vnode.type.displayName || vnode.type.name || 'Anonymous')
        : (vnode.type || 'text');
      const node = { name, depth, _fw: 'preact', children: [] };
      const kids = vnode.__k || [];
      for (const child of (Array.isArray(kids) ? kids : [])) {
        const c = this._traverse(child, depth + 1);
        if (c) node.children.push(c);
      }
      return node;
    },
  });
})();
