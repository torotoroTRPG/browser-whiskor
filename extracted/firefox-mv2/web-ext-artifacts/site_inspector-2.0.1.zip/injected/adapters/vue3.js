/**
 * adapters/vue3.js  –  MAIN world
 * Vue 3 component tree + Pinia state extraction.
 */
'use strict';

(function () {
  const registry = window.__SI_REGISTRY__;
  if (!registry) return;

  function safeClone(obj, maxLen = 2000) {
    if (obj == null || typeof obj !== 'object') return obj;
    try { const s = JSON.stringify(obj); if (s.length > maxLen) return '[truncated:' + s.length + 'chars]'; return JSON.parse(s); } catch { return '[unserializable]'; }
  }

  const vue3Plugin = {
    id: 'vue3-devtool',
    name: 'Vue 3 Analyzer',
    version: '1.0.0',
    runAt: 'load',
    realtime: false,
    priority: 10,
    emitType: 'VUE3_SNAPSHOT',
    cacheTarget: 'vue/',

    _app: null,

    detect() {
      return !!(
        window.__VUE__ ||
        document.querySelector('[data-v-app]')?.__vue_app__ ||
        document.querySelector('#app')?.__vue_app__
      );
    },

    install(api) {
      const self = this;
      // Intercept Vue DevTools hook to grab app instance early
      const existing = window.__VUE_DEVTOOLS_GLOBAL_HOOK__;
      if (existing) {
        const origEmit = existing.emit?.bind(existing);
        existing.emit = function (event, ...args) {
          if (event === 'app:init') self._app = args[0];
          return origEmit?.(event, ...args);
        };
      }
    },

    collect(api) {
      const app = this._findApp();
      if (!app) return null;

      let componentTree = null;
      try { componentTree = this._traverseVue3(app._instance); } catch (_) {}

      return {
        capturedAt: Date.now(),
        framework: 'vue3',
        version: app.version || null,
        componentTree,
        globalProperties: Object.keys(app.config?.globalProperties || {}),
        plugins: app._context?.provides ? Object.keys(app._context.provides).slice(0, 20) : [],
        pinia: this._extractPinia(app),
      };
    },

    _findApp() {
      if (this._app) return this._app;
      const selectors = ['[data-v-app]', '#app', '#root', 'body'];
      for (const s of selectors) {
        const el = document.querySelector(s);
        if (el?.__vue_app__) return (this._app = el.__vue_app__);
      }
      // windowスキャン（最終手段）
      for (const key of Object.keys(window)) {
        try { if (window[key]?._context?.app) return (this._app = window[key]); } catch (_) {}
      }
      return null;
    },

    _traverseVue3(instance, depth = 0) {
      if (!instance || depth > 40) return null;
      const node = {
        name: instance.type?.name || instance.type?.__name || instance.type?.displayName || 'Anonymous',
        depth,
        props: safeClone(instance.props),
        setupState: safeClone(instance.setupState),
        data: safeClone(instance.data),
        children: [],
        _fw: 'vue3',
      };
      const subTree = instance.subTree;
      if (subTree?.component) {
        const c = this._traverseVue3(subTree.component, depth + 1);
        if (c) node.children.push(c);
      }
      const children = Array.isArray(subTree?.children) ? subTree.children : [];
      for (const child of children) {
        if (child?.component) {
          const c = this._traverseVue3(child.component, depth + 1);
          if (c) node.children.push(c);
        }
      }
      return node;
    },

    _extractPinia(app) {
      try {
        const sym = Object.getOwnPropertySymbols(app._context?.provides || {})
          .find(s => s.toString().includes('pinia'));
        if (!sym) return null;
        const pinia = app._context.provides[sym];
        const storeIds = [...(pinia._s || new Map()).keys()];
        const state = {};
        for (const [id, store] of (pinia._s || new Map())) {
          try { state[id] = JSON.parse(JSON.stringify(pinia.state.value?.[id] || {}).slice(0, 1000)); }
          catch { state[id] = '[unserializable]'; }
        }
        return { stores: storeIds, state };
      } catch (_) { return null; }
    },
  };

  registry.register(vue3Plugin);
})();
