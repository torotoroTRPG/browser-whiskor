/**
 * adapters/alpine.js  –  MAIN world
 */
'use strict';
(function () {
  const registry = window.__SI_REGISTRY__;
  if (!registry) return;
  registry.register({
    id: 'alpine-js', name: 'Alpine.js Analyzer', version: '1.0.0',
    runAt: 'load', realtime: false, priority: 10,
    emitType: 'ALPINE_SNAPSHOT', cacheTarget: 'alpine/',

    detect() { return !!(window.Alpine || document.querySelector('[x-data]')); },
    install(api) {},
    collect(api) {
      const components = [];
      document.querySelectorAll('[x-data]').forEach(el => {
        try {
          const stack = el._x_dataStack;
          components.push({
            element: el.tagName.toLowerCase(), id: el.id || null,
            data: stack ? JSON.parse(JSON.stringify(stack[0] || {}).slice(0, 1000)) : null,
          });
        } catch (_) {
          components.push({ element: el.tagName.toLowerCase(), id: el.id || null, data: null });
        }
      });
      const stores = {};
      try {
        const sp = window.Alpine?.store?.();
        if (sp && typeof sp === 'object') {
          for (const k of Object.keys(sp)) {
            try { stores[k] = JSON.parse(JSON.stringify(sp[k]).slice(0, 500)); }
            catch { stores[k] = '[unserializable]'; }
          }
        }
      } catch (_) {}
      return {
        capturedAt: Date.now(), framework: 'alpine',
        version: window.Alpine?.version || null,
        components, stores,
      };
    },
  });
})();
