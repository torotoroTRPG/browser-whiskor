/**
 * adapters/vue2.js  –  MAIN world
 * Vue 2 component tree + Vuex state extraction.
 */
'use strict';

(function () {
  const registry = window.__SI_REGISTRY__;
  if (!registry) return;

  function safeClone(obj, maxLen = 1000) {
    if (obj == null || typeof obj !== 'object') return obj;
    try { const s = JSON.stringify(obj); if (s.length > maxLen) return '[truncated:' + s.length + 'chars]'; return JSON.parse(s); } catch { return '[unserializable]'; }
  }

  const vue2Plugin = {
    id: 'vue2-devtool',
    name: 'Vue 2 Analyzer',
    version: '1.0.0',
    runAt: 'load',
    realtime: false,
    priority: 11,
    emitType: 'VUE2_SNAPSHOT',
    cacheTarget: 'vue2/',

    detect() {
      return !!(window.Vue?.version?.startsWith('2') ||
                document.querySelector('#app')?.__vue__);
    },

    install(api) {
      // Vue 2 DevTools hook
      const existing = window.__VUE_DEVTOOLS_GLOBAL_HOOK__;
      if (existing && !existing._SI_patched) {
        existing._SI_patched = true;
        const origInit = existing.emit?.bind(existing);
        existing.emit = function (event, ...args) {
          if (event === 'init') window.__SI_VUE2_INSTANCE__ = args[0];
          return origInit?.(event, ...args);
        };
      }
    },

    collect(api) {
      const rootEl = document.querySelector('#app') || document.querySelector('[id]');
      const vm = window.__SI_VUE2_INSTANCE__ || rootEl?.__vue__;
      if (!vm) return null;

      return {
        capturedAt: Date.now(),
        framework: 'vue2',
        version: window.Vue?.version || null,
        componentTree: this._traverseVue2(vm),
        vuex: this._extractVuex(vm),
      };
    },

    _traverseVue2(vm, depth = 0) {
      if (!vm || depth > 40) return null;
      const node = {
        name: vm.$options?.name || vm.$options?._componentTag || 'Anonymous',
        depth,
        data: safeClone(vm.$data),
        props: safeClone(vm.$props),
        computed: Object.keys(vm._computedWatchers || {}),
        children: [],
        _fw: 'vue2',
      };
      for (const child of (vm.$children || [])) {
        const c = this._traverseVue2(child, depth + 1);
        if (c) node.children.push(c);
      }
      return node;
    },

    _extractVuex(vm) {
      try {
        const store = vm.$store;
        if (!store) return null;
        return {
          state: safeClone(store.state, 2000),
          getters: Object.keys(store.getters || {}),
          modules: Object.keys(store._modules?.root?._children || {}),
        };
      } catch (_) { return null; }
    },
  };

  registry.register(vue2Plugin);
})();
