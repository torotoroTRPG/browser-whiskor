/**
 * adapters/react.js  –  MAIN world
 *
 * Bippy (window.Bippy) ベースの React Fiber アナライザー。
 * bippy.iife.js が先に読み込まれている前提。
 *
 * 取得データ:
 *   - コンポーネントツリー (名前・props・hooks・深度)
 *   - useState / useReducer / useRef / useEffect / useMemo / useCallback / useContext
 *   - Redux (react-redux Provider) / Zustand / Jotai / React Query 状態
 *   - React Router / TanStack Router ルート情報
 *   - レンダリング統計 (selfTime / totalTime)
 *   - React バージョン・ビルド種別 (dev/prod)
 */
'use strict';

(function () {
  const registry = window.__SI_REGISTRY__;
  if (!registry) return;

  if (typeof window.Bippy === 'undefined') {
    console.warn('[SI] bippy not loaded — React adapter disabled');
    return;
  }

  const B = window.Bippy;

  // ── Safe serializer ──────────────────────────────────────────────────────
  function safeVal(v, depth, seen) {
    depth = depth == null ? 0 : depth;
    seen  = seen  || new WeakSet();
    if (v === null || v === undefined) return v;
    if (typeof v === 'function')  return '[fn]';
    if (typeof v === 'symbol')    return String(v);
    if (typeof v !== 'object')    return v;
    if (depth > 3)                return '[deep]';
    if (seen.has(v))              return '[circular]';
    seen.add(v);
    if (Array.isArray(v)) {
      return v.slice(0, 20).map(function(i) { return safeVal(i, depth + 1, seen); });
    }
    var keys = Object.keys(v).slice(0, 30);
    var out  = {};
    for (var ki = 0; ki < keys.length; ki++) {
      var k = keys[ki];
      try { out[k] = safeVal(v[k], depth + 1, seen); }
      catch (_) { out[k] = '[err]'; }
    }
    return out;
  }

  // ── フック型判定 ─────────────────────────────────────────────────────────
  function classifyHook(hook) {
    if (!hook) return { type: 'unknown' };
    var q   = hook.queue;
    var val = hook.memoizedState;

    // useEffect / useLayoutEffect / useInsertionEffect
    if (val && typeof val === 'object' && 'tag' in val && 'create' in val) {
      var t = val.tag;
      if (t === 4) return { type: 'useLayoutEffect' };
      if (t === 8) return { type: 'useInsertionEffect' };
      return { type: 'useEffect' };
    }

    // useRef
    if (val && typeof val === 'object' && 'current' in val && !q) {
      return { type: 'useRef', value: safeVal(val.current) };
    }

    // useState / useReducer
    if (q && typeof q.dispatch === 'function') {
      var fn   = q.lastRenderedReducer;
      var name = fn ? (fn.name || fn.toString().slice(0, 30)) : '';
      var isState = name.indexOf('basicState') !== -1 ||
                    name.indexOf('identity')   !== -1 ||
                    (fn && fn.length === 1);
      return { type: isState ? 'useState' : 'useReducer', value: safeVal(val) };
    }

    // useContext
    if (q === null && hook.dependencies) {
      return { type: 'useContext', value: safeVal(val) };
    }

    // useMemo (queue null, val は [value, deps])
    if (q == null && Array.isArray(val)) {
      return { type: 'useMemo', value: safeVal(val[0]) };
    }

    return { type: 'hook', value: safeVal(val) };
  }

  function getHooks(fiber, maxHooks) {
    maxHooks = maxHooks || 25;
    var hooks = [];
    var node  = fiber.memoizedState;
    var i     = 0;
    while (node && i < maxHooks) {
      hooks.push(classifyHook(node));
      node = node.next;
      i++;
    }
    return hooks;
  }

  // ── 状態管理ライブラリ検出 ────────────────────────────────────────────────
  function detectStateManagers(fiberRoot) {
    var result = {
      redux:      null,
      zustand:    [],
      jotai:      null,
      reactQuery: null,
      router:     null,
    };

    // React Query: window に QueryClient が露出している場合
    try {
      var rqc = window.__reactQueryClient || window.__tanstackQueryClient;
      if (rqc && typeof rqc.getQueryCache === 'function') {
        result.reactQuery = safeVal(
          rqc.getQueryCache().getAll().slice(0, 20).map(function(q) {
            return { key: q.queryKey, status: q.state.status, data: safeVal(q.state.data, 1) };
          })
        );
      }
    } catch (_) {}

    try {
      B.traverseFiberSync(fiberRoot.current, function(fiber) {
        if (!B.isCompositeFiber(fiber)) return;
        var name  = B.getDisplayName(fiber.type) || '';
        var props = fiber.memoizedProps || {};

        // Redux
        if (!result.redux && (name === 'Provider' || name === 'ReactReduxContext')) {
          if (props.store && typeof props.store.getState === 'function') {
            try { result.redux = safeVal(props.store.getState(), 2); } catch (_) {}
          }
        }

        // Zustand (useSyncExternalStore / getSnapshot ベース)
        var h = fiber.memoizedState;
        var hc = 0;
        while (h && hc < 30) {
          var hq = h.queue;
          if (hq && typeof hq.getSnapshot === 'function' && typeof hq.subscribe === 'function') {
            try {
              var snap = hq.getSnapshot();
              if (snap && typeof snap === 'object') result.zustand.push(safeVal(snap, 2));
            } catch (_) {}
          }
          h = h.next;
          hc++;
        }

        // React Query QueryClientProvider
        if (!result.reactQuery && name === 'QueryClientProvider') {
          if (props.client && typeof props.client.getQueryCache === 'function') {
            try {
              result.reactQuery = safeVal(
                props.client.getQueryCache().getAll().slice(0, 20).map(function(q) {
                  return { key: q.queryKey, status: q.state.status, data: safeVal(q.state.data, 1) };
                })
              );
            } catch (_) {}
          }
        }

        // React Router / TanStack Router
        if (!result.router && (
          name === 'Router' || name === 'BrowserRouter' || name === 'HashRouter' ||
          name === 'MemoryRouter' || name === 'RouterProvider' || name === 'StaticRouter'
        )) {
          try {
            result.router = {
              type:     name,
              basename: props.basename || null,
              location: safeVal((props.router && props.router.state && props.router.state.location) || props.location, 1),
              routes:   (props.router && props.router.routes) ? props.router.routes.length : null,
            };
          } catch (_) {}
        }

        // Jotai Provider
        if (!result.jotai && name === 'Provider' && !props.store) {
          try {
            var jh = fiber.memoizedState;
            while (jh) {
              var ms = jh.memoizedState;
              if (ms && typeof ms === 'object' && 'current' in ms) {
                var ref = ms.current;
                if (ref && typeof ref.get === 'function' && typeof ref.set === 'function') {
                  result.jotai = '[Jotai store detected]';
                  break;
                }
              }
              jh = jh.next;
            }
          } catch (_) {}
        }
      });
    } catch (_) {}

    if (result.zustand.length === 0) result.zustand = null;
    return result;
  }

  // ── Fiber シリアライズ ────────────────────────────────────────────────────
  function serializeFiber(fiber, depth, maxDepth, maxProps) {
    depth    = depth    == null ? 0  : depth;
    maxDepth = maxDepth == null ? 80 : maxDepth;
    maxProps = maxProps == null ? 30 : maxProps;

    if (!fiber || depth > maxDepth) return null;

    var name = B.getDisplayName(fiber.type) ||
               (B.isHostFiber(fiber) ? fiber.type : null) ||
               'Unknown';
    var tag  = fiber.tag;

    // DOMルートノードをスキップ
    if (B.isHostFiber(fiber) && ['html','head','body','script'].includes(name)) return null;

    var node = { n: name, t: tag, d: depth };

    // タイミング (Profiler)
    var timings = B.getTimings(fiber);
    if (timings.totalTime > 0) {
      node.ms = {
        self:  parseFloat(timings.selfTime.toFixed(2)),
        total: parseFloat(timings.totalTime.toFixed(2)),
      };
    }

    // Props (コンポーネントのみ)
    if (B.isCompositeFiber(fiber) && fiber.memoizedProps) {
      var props = {};
      var count = 0;
      var pkeys = Object.keys(fiber.memoizedProps);
      for (var pi = 0; pi < pkeys.length && count < maxProps; pi++) {
        var pk = pkeys[pi];
        if (pk === 'children') continue;
        try {
          var pv = fiber.memoizedProps[pk];
          if (typeof pv !== 'function') { props[pk] = safeVal(pv); count++; }
        } catch (_) {}
      }
      if (count > 0) node.p = props;
    }

    // Hooks (FunctionComponent=0, SimpleMemo=15)
    if (tag === 0 || tag === 15) {
      var hooks = getHooks(fiber);
      if (hooks.length > 0) node.h = hooks;
    }

    // ContextProvider の value
    if (tag === 10) {
      try { node.ctx = safeVal(fiber.memoizedProps && fiber.memoizedProps.value, 1); } catch (_) {}
    }

    // 子ノード
    var children = [];
    var child = fiber.child;
    while (child) {
      var c = serializeFiber(child, depth + 1, maxDepth, maxProps);
      if (c) children.push(c);
      child = child.sibling;
    }
    if (children.length) node.c = children;

    return node;
  }

  // ── Plugin 登録 ─────────────────────────────────────────────────────────
  var reactPlugin = {
    id:          'react-fiber',
    name:        'React Fiber Analyzer (bippy)',
    version:     '2.0.0',
    runAt:       'document_start',
    realtime:    false,
    priority:    1,
    requires:    [],
    emitType:    'REACT_SNAPSHOT',
    cacheTarget: 'react/',

    _debounceTimer: null,
    _reactVersion:  null,
    _buildType:     null,

    detect: function() {
      return B.hasRDTHook() || !!window.React || !!window.__webpack_require__;
    },

    install: function(api) {
      var self = this;

      B.instrument({
        name: 'site-inspector',

        onActive: function() {
          try {
            var hook = B.getRDTHook();
            if (hook && hook.renderers) {
              for (var renderer of hook.renderers.values()) {
                self._reactVersion = renderer.version || null;
                self._buildType    = B.detectReactBuildType(renderer);
                break;
              }
            }
          } catch (_) {}
        },

        onCommitFiberRoot: function(_rid, _root, _priority) {
          clearTimeout(self._debounceTimer);
          self._debounceTimer = setTimeout(function() {
            if (!registry._isEnabled('react-fiber')) return;
            var data = self.collect(api);
            if (data) api.emit(self.emitType, data, false);
          }, 200);
        },
      });
    },

    collect: function(api) {
      var cfg      = (api.getConfig().options && api.getConfig().options.react) || {};
      var maxDepth = cfg.maxDepth || 80;
      var maxProps = cfg.maxProps || 30;

      var fiberRoots = B._fiberRoots;
      if (!fiberRoots || fiberRoots.size === 0) return null;

      var fiberRoot = fiberRoots.values().next().value;
      if (!fiberRoot || !fiberRoot.current) return null;

      var componentTree = null;
      try {
        componentTree = serializeFiber(fiberRoot.current, 0, maxDepth, maxProps);
      } catch (err) {
        api.log('warn', 'react-fiber: serialize failed: ' + err.message);
      }

      var sm = {};
      try { sm = detectStateManagers(fiberRoot); } catch (_) {}

      return {
        capturedAt:  Date.now(),
        version:     this._reactVersion,
        buildType:   this._buildType,
        componentTree: componentTree,
        redux:       sm.redux      || null,
        zustand:     sm.zustand    || null,
        reactQuery:  sm.reactQuery || null,
        router:      sm.router     || null,
        jotai:       sm.jotai      || null,
      };
    },
  };

  registry.register(reactPlugin);
})();
