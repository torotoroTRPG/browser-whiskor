/**
 * injected/collector.js  –  MAIN world, document_start
 * Entry point. All adapters/analyzers have already registered themselves.
 * This file:
 *  1. Calls registry.installAll() → installs document_start plugins
 *  2. Wires up DOMContentLoaded / load events
 *  3. Listens for CONFIG_UPDATE from bridge
 */
'use strict';

(function () {
  const registry = window.__SI_REGISTRY__;
  if (!registry) { console.error('[SI] registry not found'); return; }
  if (window.__SI_COLLECTOR_INIT__) return;
  window.__SI_COLLECTOR_INIT__ = true;

  // ── 1. Install document_start plugins (React hook, network, perf, mutations)
  registry.installAll();

  // ── 2. DOMContentLoaded → run 'DOMContentLoaded' plugins (text-coords, ui-catalog)
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', onDOMReady, { once: true });
  } else {
    // Already past DOMContentLoaded
    setTimeout(onDOMReady, 0);
  }

  // ── 3. window load → run 'load' plugins (vue3, angular, css, dom-generic, etc.)
  window.addEventListener('load', onLoad, { once: true });

  // ── 4. CONFIG_UPDATE from bridge.js (mode / plugin on-off changes)
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data?.__SITE_INSPECTOR__ && event.data.type === 'CONFIG_UPDATE') {
      registry.updateConfig(event.data.payload);
      // Persist config for next page load (fast path)
      try { sessionStorage.setItem('__SI_CONFIG__', JSON.stringify(event.data.payload)); } catch (_) {}
    }
    // Manual collect trigger
    if (event.data?.__SITE_INSPECTOR__ && event.data.type === 'MANUAL_COLLECT') {
      const ids = event.data.payload?.plugins;
      if (Array.isArray(ids)) {
        ids.forEach(id => registry.runPlugin(id));
      } else {
        registry.runAt('manual');
      }
    }
  });

  // ── Detect & emit framework summary on load
  window.addEventListener('load', () => {
    setTimeout(() => {
      const detected = [...registry._plugins.values()]
        .filter(p => { try { return p.detect?.(); } catch { return false; } })
        .map(p => ({ id: p.id, name: p.name, frameworkId: p.frameworkId || null }));
      window.postMessage({
        __SITE_INSPECTOR__: true,
        type: 'FRAMEWORK_DETECTION',
        payload: {
          capturedAt: Date.now(),
          url: location.href,
          detected,
        },
      }, '*');
    }, 200);
  }, { once: true });

  function onDOMReady() {
    setTimeout(() => registry.runAt('DOMContentLoaded'), 150);
  }

  function onLoad() {
    setTimeout(() => registry.runAt('load'), 400);
    // Source catalog
    setTimeout(() => {
      const resources = performance.getEntriesByType('resource').map(r => ({
        url:          r.name,
        type:         r.initiatorType,
        duration:     Math.round(r.duration),
        transferSize: r.transferSize,
        startTime:    Math.round(r.startTime),
      }));
      window.postMessage({
        __SITE_INSPECTOR__: true,
        type: 'SOURCE_CATALOG',
        payload: { capturedAt: Date.now(), resources },
      }, '*');
    }, 500);
  }
})();
